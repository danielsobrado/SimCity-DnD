import { readFile, readdir } from 'node:fs/promises';

const ROOT = new URL('../public/assets/icons/', import.meta.url);
const categories = ['biomes', 'buildings', 'resources'];
let count = 0;

for (const category of categories) {
  const directory = new URL(`${category}/`, ROOT);
  for (const file of await readdir(directory)) {
    if (!file.endsWith('.svg')) continue;
    const content = await readFile(new URL(file, directory), 'utf8');
    if (!content.includes('<svg') || content.includes('<rect width="256" height="256"')) {
      throw new Error(`Invalid transparent SVG: ${category}/${file}`);
    }
    count += 1;
  }
}

if (count < 15) throw new Error(`Expected at least 15 SVG assets, found ${count}`);
console.log(`Verified ${count} transparent SVG assets.`);

# SimCity DnD Starter

A small, deliberately limited vertical slice for a D&D-inspired city builder built with Three.js.

## Included

- Three.js r184, TypeScript, and Vite scaffold.
- Isometric-style orthographic camera.
- Deterministic biome-colored terrain.
- Click-to-place building prototypes.
- Lightweight city resource simulation.
- Transparent PNG starter icons.
- Architecture and roadmap documents for a chunked huge world.

## Run

```bash
npm install
npm run dev
```

## First milestone

Build one enjoyable 30-minute loop in one biome:

1. Place a town hall.
2. Gather food, wood, and stone.
3. Add homes and jobs.
4. Survive one D&D-flavored event.
5. Save and reload the settlement.

Do not begin with a seamless continent, multiplayer, procedural quests, or dozens of biomes. They depend on a stable placement, economy, save, and streaming contract.

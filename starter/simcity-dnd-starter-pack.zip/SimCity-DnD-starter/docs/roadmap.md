# Roadmap

## Phase 0: decisions

- Choose art direction: stylized low-poly is recommended.
- Choose tile scale and building footprint rules.
- Define simulation tick, save schema, and deterministic seed policy.
- Define a content license policy before importing external D&D material.

## Phase 1: playable settlement slice

- One temperate biome.
- Terrain selection and camera.
- Roads and six buildings.
- Food, wood, stone, gold, population, jobs, and housing.
- Construction costs and time.
- Save/load.
- One event: goblin raids.
- One response: build defense or hire an adventuring party.

Acceptance: a new player can build, fail, recover, save, and reload during a 30-minute session.

## Phase 2: city depth

- Service coverage.
- Citizen households and schedules.
- Building upgrades.
- District overlays.
- Trade and caravans.
- Crime, fire, disease, faith, and mana.

## Phase 3: D&D layer

- Races, classes, factions, deities, monsters, lairs, quests, and adventuring parties.
- Use original names and rules unless the project intentionally adopts content covered by an appropriate open license.

## Phase 4: streamed regions

- Chunk streaming and workers.
- Regional road and river graphs.
- Settlement simulation LOD.
- Multiple biomes.
- Floating origin.
- Performance and memory acceptance tests.

## Phase 5: campaign world

- Several settlements.
- Diplomacy, armies, planes, legendary threats, and long-term history.
- Modding and content tools.

## Avoid early

- Multiplayer.
- Fully simulated global population.
- Procedural everything.
- Complex combat rendered at city scale.
- A custom engine rewrite.
- Photorealistic assets.

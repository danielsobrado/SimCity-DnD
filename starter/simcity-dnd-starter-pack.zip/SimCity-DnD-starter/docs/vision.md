# Product vision

## Player fantasy

You are not only a mayor. You are the ruler, architect, quartermaster, and patron of adventurers in a dangerous fantasy realm.

The city grows because ordinary citizens work, while heroes solve exceptional problems outside the walls.

## Core loop

1. Survey land and establish a settlement.
2. Zone or place homes, farms, workshops, roads, defenses, temples, and magical infrastructure.
3. Balance food, labor, materials, gold, safety, faith, and mana.
4. Respond to D&D-style events: monsters, curses, faction conflicts, ruins, portals, plagues, and diplomacy.
5. Recruit adventuring parties and issue contracts.
6. Gain influence, unlock laws, expand into new biomes, and connect settlements.

## Strong differentiators

- Citizens have race, profession, faith, needs, relationships, and risk tolerance.
- Adventurers are rare agents with classes, levels, equipment, and party composition.
- Monsters belong to ecosystems and lairs rather than appearing from random timers.
- Biomes alter construction, agriculture, travel, disease, magic, and combat.
- Deities and planar forces can change city rules.
- A settlement can become a trade capital, fortress, holy city, magical academy, criminal haven, or monster-friendly enclave.

## Scope rule

The first release should simulate depth at settlement scale. The huge map is a streaming and strategic layer, not an excuse to render every distant citizen.

# Architecture

## Recommended boundaries

- `render`: Three.js scene ownership, materials, GPU resources, picking, and visual LOD.
- `world`: deterministic terrain, biome, hydrology, roads, parcels, chunks, and spatial queries.
- `simulation`: authoritative headless city state and fixed-step systems.
- `buildings`: catalog, footprints, construction stages, services, and upgrades.
- `agents`: citizens, visitors, adventurers, monsters, parties, and schedules.
- `content`: data-driven races, classes, buildings, events, factions, spells, and biomes.
- `persistence`: versioned snapshots, command log, migrations, and deterministic seeds.
- `ui`: tools, overlays, inspectors, notifications, and accessibility.
- `workers`: terrain generation, pathfinding, aggregation, save compression, and heavy queries.

The simulation must not depend on Three.js objects. Render objects are disposable projections of simulation state.

## Huge world

Use hierarchical spatial authority:

- World: campaign-scale map and climate.
- Region: biome, faction, roads, rivers, settlements, and strategic events.
- Chunk: streamed terrain and props.
- Parcel/tile: placement and local navigation.
- Entity: citizens and buildings.

Near the camera, simulate individual agents. Far away, aggregate them by household, workplace, district, caravan, army, or settlement.

## Rendering

- GPU instancing for terrain details, vegetation, roads, walls, props, and repeated building modules.
- Texture arrays or atlases grouped by material family.
- Separate visual LOD from simulation LOD.
- Floating origin for long travel.
- Chunk lifecycle with explicit CPU, GPU, and disposal budgets.
- Occlusion and frustum culling before adding complex post-processing.
- WebGPU can be evaluated later; do not make the first playable loop depend on it.

## Terrain

Start with a height field plus tile/parcel metadata. Avoid editable voxels unless vertical excavation is central to the game.

Persist changes as sparse edits over deterministic procedural generation:

- terrain height deltas;
- biome overrides;
- roads and parcel ownership;
- water-control structures;
- placed objects;
- discovered locations.

## Pathfinding

Use layers:

- local navigation grid or navmesh per loaded chunk;
- district road graph;
- regional travel graph;
- portal graph for interiors and special locations.

Never run full-world A* for a citizen.

## Simulation clock

Use fixed ticks and system budgets. Important state changes are commands/events. Rendering interpolates and may run at a different frequency.

## Save contract

Save semantic state, not Three.js internals. Every save carries a schema version, world seed, content version, and migration path.

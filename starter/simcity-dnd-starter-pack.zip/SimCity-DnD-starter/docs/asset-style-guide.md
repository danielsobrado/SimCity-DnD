# Asset style guide

## Starter direction

- Stylized low-poly fantasy.
- Readable silhouette at isometric camera distance.
- Large shape language and limited small detail.
- Neutral lighting baked only into UI icons, not 3D materials.
- Consistent footprint and entrance direction.
- Separate construction stages.
- GLB for 3D assets, PNG with alpha for UI icons.

## 3D budgets

These are initial targets, not permanent limits:

- Small prop: 100-800 triangles.
- Standard building: 2,000-12,000 triangles.
- Landmark: 15,000-40,000 triangles.
- Citizen LOD0: 4,000-12,000 triangles.
- Citizen distant representation: impostor or very low LOD.
- One material family per modular set when possible.

## Asset pipeline

1. Concept and silhouette.
2. Blockout against the real camera.
3. Modular production.
4. UV and material-family assignment.
5. LODs or impostors.
6. Collision and footprint metadata.
7. GLB export.
8. automated validation for transforms, dimensions, materials, and texture size.

## Naming

`category-biome-faction-purpose-variant-lod`

Example: `building-plains-common-inn-a-lod0.glb`.

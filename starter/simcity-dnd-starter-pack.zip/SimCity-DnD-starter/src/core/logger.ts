const LOGGER_PREFIX = '[simcity-dnd]';

export const logger = {
  info(message: string, details?: unknown): void {
    console.info(LOGGER_PREFIX, message, details ?? '');
  },
  warn(message: string, details?: unknown): void {
    console.warn(LOGGER_PREFIX, message, details ?? '');
  },
  error(message: string, error?: unknown): void {
    console.error(LOGGER_PREFIX, message, error ?? '');
  },
};

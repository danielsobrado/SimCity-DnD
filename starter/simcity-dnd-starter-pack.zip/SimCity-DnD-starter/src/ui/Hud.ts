import type { ResourceStock } from '../config/types';
import type { BuildingId } from '../buildings/catalog';
import { BUILDING_CATALOG } from '../buildings/catalog';

const RESOURCE_ICONS: Readonly<Record<keyof ResourceStock, string>> = {
  food: '/assets/icons/resources/food.svg',
  wood: '/assets/icons/resources/wood.svg',
  stone: '/assets/icons/resources/stone.svg',
  gold: '/assets/icons/resources/gold.svg',
  mana: '/assets/icons/resources/mana.svg',
};

export class Hud {
  private readonly values = new Map<keyof ResourceStock, HTMLElement>();

  public constructor(
    parent: HTMLElement,
    onBuildingSelected: (id: BuildingId) => void,
  ) {
    const root = document.createElement('div');
    root.className = 'hud';

    const topbar = document.createElement('div');
    topbar.className = 'topbar';
    for (const resource of Object.keys(RESOURCE_ICONS) as (keyof ResourceStock)[]) {
      const item = document.createElement('div');
      item.className = 'resource';
      item.innerHTML = `<img src="${RESOURCE_ICONS[resource]}" alt="" /><strong>${resource}</strong> <span>0</span>`;
      this.values.set(resource, item.querySelector('span') as HTMLElement);
      topbar.append(item);
    }

    const toolbar = document.createElement('div');
    toolbar.className = 'toolbar';
    let first = true;
    for (const definition of Object.values(BUILDING_CATALOG)) {
      const button = document.createElement('button');
      button.className = 'tool';
      button.type = 'button';
      button.setAttribute('aria-pressed', String(first));
      button.innerHTML = `<img src="${definition.icon}" alt="" /><span>${definition.name}</span>`;
      button.addEventListener('click', () => {
        for (const sibling of toolbar.querySelectorAll('.tool')) {
          sibling.setAttribute('aria-pressed', 'false');
        }
        button.setAttribute('aria-pressed', 'true');
        onBuildingSelected(definition.id);
      });
      toolbar.append(button);
      first = false;
    }

    const help = document.createElement('div');
    help.className = 'help';
    help.textContent = 'Left click: place. Middle drag: pan. Right drag: rotate. Wheel: zoom.';

    root.append(topbar, toolbar, help);
    parent.append(root);
  }

  public update(resources: ResourceStock): void {
    for (const [key, value] of this.values) {
      value.textContent = Math.floor(resources[key]).toString();
    }
  }
}

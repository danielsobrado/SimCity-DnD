export type BiomeId =
  | 'plains'
  | 'forest'
  | 'desert'
  | 'tundra'
  | 'swamp'
  | 'volcanic';

export interface TileSample {
  x: number;
  z: number;
  elevation: number;
  moisture: number;
  heat: number;
  biome: BiomeId;
}

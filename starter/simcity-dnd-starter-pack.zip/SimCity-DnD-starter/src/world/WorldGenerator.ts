import type { BiomeId, TileSample } from './types';

const BIOME_COLORS: Readonly<Record<BiomeId, number>> = {
  plains: 0x668c4a,
  forest: 0x345b3c,
  desert: 0xb98a50,
  tundra: 0x9faea8,
  swamp: 0x4d6951,
  volcanic: 0x554b49,
};

function hash2D(x: number, z: number, seed: number): number {
  let value = Math.imul(x, 374761393) + Math.imul(z, 668265263);
  value = Math.imul(value ^ (value >>> 13), 1274126177) ^ seed;
  return ((value ^ (value >>> 16)) >>> 0) / 4294967295;
}

function smoothNoise(x: number, z: number, seed: number, scale: number): number {
  const sx = x / scale;
  const sz = z / scale;
  const x0 = Math.floor(sx);
  const z0 = Math.floor(sz);
  const tx = sx - x0;
  const tz = sz - z0;
  const fade = (v: number) => v * v * (3 - 2 * v);
  const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

  const a = hash2D(x0, z0, seed);
  const b = hash2D(x0 + 1, z0, seed);
  const c = hash2D(x0, z0 + 1, seed);
  const d = hash2D(x0 + 1, z0 + 1, seed);

  return lerp(lerp(a, b, fade(tx)), lerp(c, d, fade(tx)), fade(tz));
}

function classifyBiome(elevation: number, moisture: number, heat: number): BiomeId {
  if (elevation > 0.82) return heat < 0.45 ? 'tundra' : 'volcanic';
  if (heat > 0.68 && moisture < 0.42) return 'desert';
  if (moisture > 0.72) return 'swamp';
  if (moisture > 0.52) return 'forest';
  return 'plains';
}

export class WorldGenerator {
  public constructor(private readonly seed: number) {}

  public sample(x: number, z: number): TileSample {
    const elevation =
      smoothNoise(x, z, this.seed, 34) * 0.68 +
      smoothNoise(x, z, this.seed + 19, 11) * 0.32;
    const moisture = smoothNoise(x, z, this.seed + 103, 25);
    const heat = smoothNoise(x, z, this.seed + 307, 46);

    return {
      x,
      z,
      elevation,
      moisture,
      heat,
      biome: classifyBiome(elevation, moisture, heat),
    };
  }

  public colorFor(biome: BiomeId): number {
    return BIOME_COLORS[biome];
  }
}

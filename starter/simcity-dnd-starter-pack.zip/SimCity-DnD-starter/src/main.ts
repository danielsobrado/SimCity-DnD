import './styles.css';
import { loadConfig } from './config/loadConfig';
import { Game } from './game/Game';
import { logger } from './core/logger';

async function bootstrap(): Promise<void> {
  const container = document.querySelector<HTMLElement>('#app');
  if (!container) throw new Error('Missing #app container');

  const config = await loadConfig();
  const game = new Game(container, config);
  game.start();
  logger.info('Game started', { threeRevision: 'r184' });
}

bootstrap().catch((error: unknown) => {
  logger.error('Unable to start game', error);
  document.body.textContent = 'Unable to start SimCity DnD. Check the console for details.';
});

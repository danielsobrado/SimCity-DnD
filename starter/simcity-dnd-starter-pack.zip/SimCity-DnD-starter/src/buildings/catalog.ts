import type { ResourceStock } from '../config/types';

export type BuildingId = 'town-hall' | 'cottage' | 'farm' | 'blacksmith' | 'inn' | 'watchtower';

export interface BuildingDefinition {
  id: BuildingId;
  name: string;
  icon: string;
  footprint: readonly [number, number];
  height: number;
  color: number;
  cost: Partial<ResourceStock>;
  perTick: Partial<ResourceStock>;
}

export const BUILDING_CATALOG: Readonly<Record<BuildingId, BuildingDefinition>> = {
  'town-hall': {
    id: 'town-hall',
    name: 'Town Hall',
    icon: '/assets/icons/buildings/town-hall.svg',
    footprint: [3, 3],
    height: 2.2,
    color: 0xc9b27e,
    cost: { wood: 40, stone: 30, gold: 10 },
    perTick: { gold: 1 },
  },
  cottage: {
    id: 'cottage',
    name: 'Cottage',
    icon: '/assets/icons/buildings/cottage.svg',
    footprint: [2, 2],
    height: 1.4,
    color: 0xb7815c,
    cost: { wood: 20, stone: 8 },
    perTick: { food: -1, gold: 1 },
  },
  farm: {
    id: 'farm',
    name: 'Farm',
    icon: '/assets/icons/buildings/farm.svg',
    footprint: [3, 3],
    height: 0.45,
    color: 0xb59a4f,
    cost: { wood: 14, stone: 4 },
    perTick: { food: 4 },
  },
  blacksmith: {
    id: 'blacksmith',
    name: 'Smithy',
    icon: '/assets/icons/buildings/blacksmith.svg',
    footprint: [2, 2],
    height: 1.55,
    color: 0x655c58,
    cost: { wood: 18, stone: 24, gold: 6 },
    perTick: { stone: -1, gold: 3 },
  },
  inn: {
    id: 'inn',
    name: 'Adventurer Inn',
    icon: '/assets/icons/buildings/inn.svg',
    footprint: [3, 2],
    height: 1.7,
    color: 0x8e5e44,
    cost: { wood: 30, stone: 12, gold: 8 },
    perTick: { food: -1, gold: 4, mana: 1 },
  },
  watchtower: {
    id: 'watchtower',
    name: 'Watchtower',
    icon: '/assets/icons/buildings/watchtower.svg',
    footprint: [1, 1],
    height: 3.1,
    color: 0x807d72,
    cost: { wood: 16, stone: 22 },
    perTick: { gold: -1 },
  },
};

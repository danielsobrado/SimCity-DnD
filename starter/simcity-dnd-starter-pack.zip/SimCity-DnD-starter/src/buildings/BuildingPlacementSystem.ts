import {
  BoxGeometry,
  Color,
  Group,
  Mesh,
  MeshStandardMaterial,
  Plane,
  Raycaster,
  Vector2,
  Vector3,
} from 'three';
import type { Camera, Object3D, Scene } from 'three';
import type { BuildingDefinition, BuildingId } from './catalog';
import { BUILDING_CATALOG } from './catalog';
import { CitySimulation } from '../simulation/CitySimulation';

const GROUND_PLANE = new Plane(new Vector3(0, 1, 0), 0);
const PLACEMENT_COLOR = new Color(0x8ccf7e);
const BLOCKED_COLOR = new Color(0xd25f57);

export class BuildingPlacementSystem {
  private readonly raycaster = new Raycaster();
  private readonly pointer = new Vector2();
  private readonly preview = new Group();
  private readonly occupied = new Set<string>();
  private selected: BuildingId = 'town-hall';
  private currentCell: readonly [number, number] | null = null;

  public constructor(
    private readonly scene: Scene,
    private readonly camera: Camera,
    private readonly element: HTMLElement,
    private readonly simulation: CitySimulation,
  ) {
    scene.add(this.preview);
    element.addEventListener('pointermove', this.onPointerMove);
    element.addEventListener('pointerdown', this.onPointerDown);
    this.rebuildPreview();
  }

  public select(id: BuildingId): void {
    this.selected = id;
    this.rebuildPreview();
  }

  public dispose(): void {
    this.element.removeEventListener('pointermove', this.onPointerMove);
    this.element.removeEventListener('pointerdown', this.onPointerDown);
    this.scene.remove(this.preview);
  }

  private readonly onPointerMove = (event: PointerEvent): void => {
    if ((event.buttons & 6) !== 0) return;
    const rect = this.element.getBoundingClientRect();
    this.pointer.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this.raycaster.setFromCamera(this.pointer, this.camera);

    const position = new Vector3();
    if (!this.raycaster.ray.intersectPlane(GROUND_PLANE, position)) return;

    const x = Math.round(position.x);
    const z = Math.round(position.z);
    this.currentCell = [x, z];
    this.preview.position.set(x, 0.05, z);
    this.updatePreviewColor();
  };

  private readonly onPointerDown = (event: PointerEvent): void => {
    if (event.button !== 0 || !this.currentCell) return;
    const definition = BUILDING_CATALOG[this.selected];
    if (!this.canPlace(definition, ...this.currentCell)) return;
    if (!this.simulation.addBuilding(definition)) return;

    const building = this.createBuilding(definition);
    building.position.set(this.currentCell[0], definition.height * 0.5, this.currentCell[1]);
    this.scene.add(building);
    this.markOccupied(definition, ...this.currentCell);
    this.updatePreviewColor();
  };

  private rebuildPreview(): void {
    this.preview.clear();
    const definition = BUILDING_CATALOG[this.selected];
    const mesh = this.createBuilding(definition);
    mesh.position.y = definition.height * 0.5;
    mesh.traverse((object: Object3D) => {
      if (object instanceof Mesh && object.material instanceof MeshStandardMaterial) {
        object.material.transparent = true;
        object.material.opacity = 0.48;
      }
    });
    this.preview.add(mesh);
    this.updatePreviewColor();
  }

  private createBuilding(definition: BuildingDefinition): Mesh {
    const geometry = new BoxGeometry(
      definition.footprint[0] * 0.85,
      definition.height,
      definition.footprint[1] * 0.85,
    );
    const material = new MeshStandardMaterial({ color: definition.color, roughness: 0.86 });
    const mesh = new Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    return mesh;
  }

  private canPlace(definition: BuildingDefinition, originX: number, originZ: number): boolean {
    for (let x = 0; x < definition.footprint[0]; x += 1) {
      for (let z = 0; z < definition.footprint[1]; z += 1) {
        if (this.occupied.has(`${originX + x}:${originZ + z}`)) return false;
      }
    }
    return this.simulation.canAfford(definition);
  }

  private markOccupied(definition: BuildingDefinition, originX: number, originZ: number): void {
    for (let x = 0; x < definition.footprint[0]; x += 1) {
      for (let z = 0; z < definition.footprint[1]; z += 1) {
        this.occupied.add(`${originX + x}:${originZ + z}`);
      }
    }
  }

  private updatePreviewColor(): void {
    if (!this.currentCell) return;
    const allowed = this.canPlace(BUILDING_CATALOG[this.selected], ...this.currentCell);
    this.preview.traverse((object: Object3D) => {
      if (object instanceof Mesh && object.material instanceof MeshStandardMaterial) {
        object.material.color.copy(allowed ? PLACEMENT_COLOR : BLOCKED_COLOR);
      }
    });
  }
}

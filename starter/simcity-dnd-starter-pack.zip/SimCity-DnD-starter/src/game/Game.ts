import {
  AmbientLight,
  Color,
  DirectionalLight,
  InstancedMesh,
  Matrix4,
  MeshStandardMaterial,
  OrthographicCamera,
  PlaneGeometry,
  Scene,
  WebGLRenderer,
} from 'three';
import type { GameConfig } from '../config/types';
import { WorldGenerator } from '../world/WorldGenerator';
import { CameraController } from '../input/CameraController';
import { CitySimulation } from '../simulation/CitySimulation';
import { BuildingPlacementSystem } from '../buildings/BuildingPlacementSystem';
import { Hud } from '../ui/Hud';

export class Game {
  private readonly scene = new Scene();
  private readonly camera = new OrthographicCamera();
  private readonly renderer: WebGLRenderer;
  private readonly cameraController: CameraController;
  private readonly simulation: CitySimulation;
  private readonly placement: BuildingPlacementSystem;
  private readonly resizeObserver: ResizeObserver;
  private simulationTimer = 0;
  private lastFrameTime = 0;

  public constructor(
    private readonly container: HTMLElement,
    private readonly config: GameConfig,
  ) {
    this.renderer = new WebGLRenderer({ antialias: config.render.antialias });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, config.render.pixelRatioCap));
    this.renderer.shadowMap.enabled = config.render.shadows;
    this.container.append(this.renderer.domElement);

    this.scene.background = new Color(0x9fc2c0);
    this.camera.near = 0.1;
    this.camera.far = 500;

    this.cameraController = new CameraController(this.camera, this.renderer.domElement, config.camera);
    this.simulation = new CitySimulation({ ...config.simulation.startingResources });
    this.placement = new BuildingPlacementSystem(
      this.scene,
      this.camera,
      this.renderer.domElement,
      this.simulation,
    );

    const hud = new Hud(this.container, (id) => this.placement.select(id));
    this.simulation.subscribe((resources) => hud.update(resources));

    this.createLights();
    this.createTerrain();

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.container);
    this.resize();
  }

  public start(): void {
    this.renderer.setAnimationLoop(this.render);
  }

  public dispose(): void {
    this.renderer.setAnimationLoop(null);
    this.resizeObserver.disconnect();
    this.cameraController.dispose();
    this.placement.dispose();
    this.renderer.dispose();
  }

  private createLights(): void {
    this.scene.add(new AmbientLight(0xb7c5bd, 1.8));
    const sun = new DirectionalLight(0xffebc2, 3.2);
    sun.position.set(25, 40, 18);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    this.scene.add(sun);
  }

  private createTerrain(): void {
    const count = this.config.world.visibleTiles ** 2;
    const geometry = new PlaneGeometry(
      this.config.world.tileSize * 0.98,
      this.config.world.tileSize * 0.98,
    );
    geometry.rotateX(-Math.PI * 0.5);
    const material = new MeshStandardMaterial({ vertexColors: true, roughness: 1 });
    const mesh = new InstancedMesh(geometry, material, count);
    mesh.receiveShadow = true;

    const generator = new WorldGenerator(this.config.world.seed);
    const matrix = new Matrix4();
    const half = this.config.world.visibleTiles * 0.5;
    let index = 0;

    for (let z = 0; z < this.config.world.visibleTiles; z += 1) {
      for (let x = 0; x < this.config.world.visibleTiles; x += 1) {
        const worldX = x - half;
        const worldZ = z - half;
        const tile = generator.sample(worldX, worldZ);
        matrix.makeTranslation(worldX, tile.elevation * 0.28, worldZ);
        mesh.setMatrixAt(index, matrix);
        mesh.setColorAt(index, new Color(generator.colorFor(tile.biome)));
        index += 1;
      }
    }

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    this.scene.add(mesh);
  }

  private readonly resize = (): void => {
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.renderer.setSize(width, height, false);
    this.cameraController.resize(width, height);
  };

  private readonly render = (timeMs: number): void => {
    const deltaSeconds = this.lastFrameTime === 0 ? 0 : Math.min((timeMs - this.lastFrameTime) / 1000, 0.25);
    this.lastFrameTime = timeMs;
    this.simulationTimer += deltaSeconds;
    const tickSeconds = 1 / this.config.simulation.ticksPerSecond;
    while (this.simulationTimer >= tickSeconds) {
      this.simulation.tick();
      this.simulationTimer -= tickSeconds;
    }
    this.renderer.render(this.scene, this.camera);
  };
}

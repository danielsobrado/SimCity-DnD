import { OrthographicCamera, Vector3 } from 'three';
import type { GameConfig } from '../config/types';

const UP = new Vector3(0, 1, 0);

export class CameraController {
  private readonly target = new Vector3();
  private dragging = false;
  private rotating = false;
  private lastX = 0;
  private lastY = 0;
  private azimuth = Math.PI * 0.25;
  private elevation = Math.PI * 0.29;
  private distance = 35;

  public constructor(
    private readonly camera: OrthographicCamera,
    private readonly element: HTMLElement,
    private readonly config: GameConfig['camera'],
  ) {
    element.addEventListener('contextmenu', (event) => event.preventDefault());
    element.addEventListener('pointerdown', this.onPointerDown);
    element.addEventListener('pointermove', this.onPointerMove);
    element.addEventListener('pointerup', this.onPointerUp);
    element.addEventListener('pointercancel', this.onPointerUp);
    element.addEventListener('wheel', this.onWheel, { passive: false });
    this.updateCamera();
  }

  public resize(width: number, height: number): void {
    const aspect = width / Math.max(height, 1);
    const half = this.config.frustumSize * 0.5;
    this.camera.left = -half * aspect;
    this.camera.right = half * aspect;
    this.camera.top = half;
    this.camera.bottom = -half;
    this.camera.updateProjectionMatrix();
  }

  public dispose(): void {
    this.element.removeEventListener('pointerdown', this.onPointerDown);
    this.element.removeEventListener('pointermove', this.onPointerMove);
    this.element.removeEventListener('pointerup', this.onPointerUp);
    this.element.removeEventListener('pointercancel', this.onPointerUp);
    this.element.removeEventListener('wheel', this.onWheel);
  }

  private readonly onPointerDown = (event: PointerEvent): void => {
    if (event.button !== 1 && event.button !== 2) return;
    this.dragging = event.button === 1;
    this.rotating = event.button === 2;
    this.lastX = event.clientX;
    this.lastY = event.clientY;
    this.element.setPointerCapture(event.pointerId);
  };

  private readonly onPointerMove = (event: PointerEvent): void => {
    const dx = event.clientX - this.lastX;
    const dy = event.clientY - this.lastY;
    this.lastX = event.clientX;
    this.lastY = event.clientY;

    if (this.dragging) {
      const right = new Vector3().setFromMatrixColumn(this.camera.matrixWorld, 0);
      const forward = new Vector3().crossVectors(UP, right).normalize();
      this.target.addScaledVector(right, -dx * this.config.panSpeed);
      this.target.addScaledVector(forward, dy * this.config.panSpeed);
    }

    if (this.rotating) {
      this.azimuth -= dx * this.config.rotateSpeed;
      this.elevation = Math.min(1.1, Math.max(0.25, this.elevation - dy * this.config.rotateSpeed));
    }

    this.updateCamera();
  };

  private readonly onPointerUp = (event: PointerEvent): void => {
    this.dragging = false;
    this.rotating = false;
    if (this.element.hasPointerCapture(event.pointerId)) {
      this.element.releasePointerCapture(event.pointerId);
    }
  };

  private readonly onWheel = (event: WheelEvent): void => {
    event.preventDefault();
    this.camera.zoom = Math.min(
      this.config.maxZoom,
      Math.max(this.config.minZoom, this.camera.zoom * Math.exp(-event.deltaY * 0.001)),
    );
    this.camera.updateProjectionMatrix();
  };

  private updateCamera(): void {
    const horizontal = Math.cos(this.elevation) * this.distance;
    this.camera.position.set(
      this.target.x + Math.sin(this.azimuth) * horizontal,
      this.target.y + Math.sin(this.elevation) * this.distance,
      this.target.z + Math.cos(this.azimuth) * horizontal,
    );
    this.camera.lookAt(this.target);
  }
}

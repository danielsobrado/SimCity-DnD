import type { ResourceStock } from '../config/types';
import type { BuildingDefinition } from '../buildings/catalog';

const RESOURCE_KEYS = ['food', 'wood', 'stone', 'gold', 'mana'] as const;

export class CitySimulation {
  private readonly resourceListeners = new Set<(resources: ResourceStock) => void>();
  private readonly buildings: BuildingDefinition[] = [];

  public constructor(private readonly resources: ResourceStock) {}

  public subscribe(listener: (resources: ResourceStock) => void): () => void {
    this.resourceListeners.add(listener);
    listener({ ...this.resources });
    return () => this.resourceListeners.delete(listener);
  }

  public canAfford(definition: BuildingDefinition): boolean {
    return RESOURCE_KEYS.every((key) => this.resources[key] >= (definition.cost[key] ?? 0));
  }

  public addBuilding(definition: BuildingDefinition): boolean {
    if (!this.canAfford(definition)) return false;

    for (const key of RESOURCE_KEYS) {
      this.resources[key] -= definition.cost[key] ?? 0;
    }

    this.buildings.push(definition);
    this.emit();
    return true;
  }

  public tick(): void {
    for (const building of this.buildings) {
      for (const key of RESOURCE_KEYS) {
        this.resources[key] = Math.max(0, this.resources[key] + (building.perTick[key] ?? 0));
      }
    }
    this.emit();
  }

  private emit(): void {
    const snapshot = { ...this.resources };
    for (const listener of this.resourceListeners) listener(snapshot);
  }
}

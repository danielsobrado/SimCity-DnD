import { parse } from 'yaml';
import type { GameConfig } from './types';

const CONFIG_URL = '/config/game.yaml';

export async function loadConfig(): Promise<GameConfig> {
  const response = await fetch(CONFIG_URL);
  if (!response.ok) {
    throw new Error(`Unable to load ${CONFIG_URL}: ${response.status}`);
  }

  return parse(await response.text()) as GameConfig;
}

export interface GameConfig {
  world: {
    seed: number;
    visibleTiles: number;
    tileSize: number;
    seaLevel: number;
  };
  camera: {
    frustumSize: number;
    minZoom: number;
    maxZoom: number;
    panSpeed: number;
    rotateSpeed: number;
  };
  simulation: {
    ticksPerSecond: number;
    startingResources: ResourceStock;
  };
  render: {
    antialias: boolean;
    pixelRatioCap: number;
    shadows: boolean;
  };
}

export interface ResourceStock {
  food: number;
  wood: number;
  stone: number;
  gold: number;
  mana: number;
}
